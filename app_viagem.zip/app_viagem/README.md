# Contagem Regressiva da Viagem

Aplicativo feito com Streamlit para exibir uma contagem regressiva até 16/07/2026.

## Como rodar no computador

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Como publicar

1. Crie uma conta no GitHub.
2. Crie um repositório novo.
3. Envie os arquivos `app.py`, `requirements.txt` e `README.md`.
4. Acesse o Streamlit Community Cloud.
5. Clique em New app.
6. Escolha o repositório e o arquivo `app.py`.
7. Clique em Deploy.

Depois disso, o app terá um link público para compartilhar.
